// This file is no longer needed - we now use Spotify API for real data
// Keeping empty file to avoid import errors during transition

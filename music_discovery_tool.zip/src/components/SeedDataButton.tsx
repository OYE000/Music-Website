// This component is no longer needed - we now use Spotify API

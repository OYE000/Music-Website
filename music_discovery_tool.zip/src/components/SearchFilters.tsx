// This component is no longer needed - replaced by SearchBar.tsx

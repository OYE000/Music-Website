// This component is no longer needed - replaced by TrackCard.tsx
